# https://nptdms.readthedocs.io/en/stable/index.html
# https://stackoverflow.com/questions/48048504/labview-tdms-file-read-with-python-pandas
# http://www.savvydiademsolutions.com/script.php?topic=Read-TDMS-file-with-Python-module-npTDMS

from nptdms import TdmsFile
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import wx

plt.close('all')

############################# file dialog ####################################

# https://stackoverflow.com/questions/9319317/quick-and-easy-file-dialog-in-python
def get_path(wildcard):
    app = wx.App(None)
    style = wx.FD_OPEN | wx.FD_FILE_MUST_EXIST
    dialog = wx.FileDialog(None, 'Open', wildcard=wildcard, style=style)
    if dialog.ShowModal() == wx.ID_OK:
        path = dialog.GetPath()
    else:
        path = None
    dialog.Destroy()
    return path

path = get_path('')

tdmsFile = TdmsFile.read(path)

# https://matplotlib.org/3.2.1/gallery/lines_bars_and_markers/simple_plot.html

############ plot two channels on graph ######################
group = 'nozzle06'
channels = ['desired position', 'actual position']
dt = 0.04

plt.figure(1)

for channel in channels:
    print(channel)
    data = (tdmsFile._groups[group]._channels[channel].data)
    numPoints = len(data)
    t = np.arange(0, (numPoints)*dt, dt)
    plt.plot(t, data)
    plt.legend(channels)

plt.title(group)
plt.xlabel('time (s)')
plt.ylabel('steps') 

############# plot all pressures on graph #####################
numGroups = len(tdmsFile._groups)
channelList = ['pressure']
dt = 0.04
legendGroup = []

plt.figure(2)

for group in tdmsFile.groups():
    print(group)
    numPoints = len(group._channels['pressure'].data)
    t = np.arange(0, (numPoints)*dt, dt)
    plt.plot(t, group._channels[channelList[0]].data)
    plt.legend(tdmsFile._groups.keys())

plt.xlabel('time (s)')    
plt.ylabel('pressure (psi)')
    
############# plot all nozzles on graph #####################
numGroups = len(tdmsFile._groups)
group = 'nozzle01'
channelList = ['desired position', 'actual position']
dt = 0.04
legendGroup = []

plt.figure(3)

for group in tdmsFile.groups():
    numPoints = len(group._channels['pressure'].data)
    t = np.arange(0, (numPoints)*dt, dt)
    plt.plot(t, group._channels[channelList[0]].data,'b')
    plt.plot(t, group._channels[channelList[1]].data,'r')
    plt.legend(tdmsFile._groups.keys())
  
plt.xlabel('time (s)')
plt.ylabel('steps')   

# https://matplotlib.org/3.1.0/gallery/subplots_axes_and_figures/subplots_demo.html


############# subplots desired & actual positon #####################

fig4, axes4 = plt.subplots(nrows=2, ncols=4, sharex=True, sharey=True, gridspec_kw = {'hspace':0.2, 'wspace':0})

for ax, group in zip(fig4.get_axes(), tdmsFile.groups()):
    ax.plot(t, group._channels['desired position'].data, label='desired')
    ax.plot(t, group._channels['actual position'].data, label='actual')
    ax.legend(loc="upper right")
    ax.set_title(group.name)


############# subplots pressure & actual position #####################
# https://matplotlib.org/gallery/api/two_scales.html
fig5, axes5 = plt.subplots(nrows=2, ncols=4, sharex='none', sharey='none', gridspec_kw = {'hspace':0.3, 'wspace':0.4})

def two_scales(ax1, time, data1, data2, c1, c2):
    ax2 = ax1.twinx()
    ax1.plot(time, data1, color=c1)
    ax1.set_xlabel('time (s)')
    ax1.set_ylabel('pressure (psi)')
    ax1.set_ylim(0,5)
    ax1.tick_params(axis='y', colors=c1)
    ax.legend('pressure', )
    ax2.plot(time, data2, color=c2)
    ax2.set_ylabel('actual position (steps)')
    ax2.set_ylim(-150,800)
    ax2.tick_params(axis='y', colors=c2)
    return ax1, ax2

for ax1, group in zip(fig5.get_axes(), tdmsFile.groups()):
    ax1, ax1a = two_scales(ax1, t, group._channels['pressure'].data, group._channels['actual position'].data,'r','b')
    ax1.set_title(group.name)
    # handles, labels = axes3.get_legend_handles_labels()
    # fig3.legend(handles, ['pressure','actual position'], loc='bottom')




print(tdmsFile._groups['nozzle01']._channels)
print(group.name)

print(tdmsFile['nozzle01']._channels['pressure'].data)              


